#include "device_driver.h"
#include <stdio.h>

void _Invalid_ISR(void)
{
	unsigned int r = Macro_Extract_Area(SCB->ICSR, 0x1ff, 0);
	printf("\nInvalid_Exception: %d!\n", r);
	printf("Invalid_ISR: %d!\n", r - 16);
	for(;;);
}

#if 0
extern volatile int Key_Pressed;

void EXTI15_10_IRQHandler(void)
{
	Key_Pressed = 1;
	
	EXTI->PR = 0x1 << 13;
	NVIC_ClearPendingIRQ(40);
	}
	
extern volatile int TIM4_Expired;
void TIM4_IRQHandler(void)
{
	// TIM4 Interrupt Pending Clear
	Macro_Clear_Bit(TIM4->SR, 0);  
	// NVIC Pending Clear
	NVIC_ClearPendingIRQ(38);
	TIM4_Expired = 1;
}
#endif
extern volatile int Uart_Data_In;
extern volatile unsigned char Uart_Data;

void USART2_IRQHandler(void)
{
	Uart_Data = (unsigned char)USART2->DR;
	TIM5_Out_PWM(10000, pwm_default+(((Uart_Data-'0')-1)*5));
	Uart_Data_In = 1;
	NVIC_ClearPendingIRQ(38);
}

